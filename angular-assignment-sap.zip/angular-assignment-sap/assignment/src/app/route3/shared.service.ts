import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private timerInput = new Subject<any>();
  private timerPause = new Subject<any>();
  timerInput$ = this.timerInput.asObservable();
  timerPause$ = this.timerPause.asObservable();

  constructor() { }

  passData(data) {
    this.timerInput.next(data);
  }

  pauseTimer(data) {
    this.timerPause.next(data);
  }
}
