import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private timerInput = new Subject<any>();
  private timerPause = new Subject<any>();
  private message = new Subject<string>()

  timerInput$ = this.timerInput.asObservable();
  timerPause$ = this.timerPause.asObservable();
  message$ = this.message.asObservable();

  constructor() { }

  passData(data) {
    this.timerInput.next(data);
  }

  pauseTimer(data) {
    this.timerPause.next(data);
  }

  getMessage(data) {
    this.message.next(data);
  }
}
