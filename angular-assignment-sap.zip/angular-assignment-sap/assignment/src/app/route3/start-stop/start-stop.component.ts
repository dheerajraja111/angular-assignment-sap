import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { SharedService } from './../shared.service';

@Component({
  selector: 'app-start-stop',
  templateUrl: './start-stop.component.html',
  styleUrls: ['./start-stop.component.scss']
})
export class StartStopComponent implements OnInit {

  @ViewChild('input') input: ElementRef;
  timeLimit: number;
  timeRemaining: number;
  isStop: boolean;
  isRunning: boolean = false;
  interval;
  data: {};

  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sharedService.timerPause$.subscribe(
      data => {
        console.log(data);
        this.timeLimit = data.timeLeft;
        this.isRunning = data.isRunning;
      }
    )
  }

  timerStart() {
    console.log(this.isRunning);
    if (this.isRunning == false) {
      if (this.timeLimit) {
        console.log(this.timeLimit);
      } else {
        this.timeLimit = this.input.nativeElement.value;
      }
      console.log(this.timeLimit);
      this.isRunning = !this.isRunning;
      this.data = {
        timeLeft: this.timeLimit,
        isRunning: this.isRunning
      }
      this.sharedService.passData(this.data);
    } else {
      this.timeLimit = this.input.nativeElement.value;
      this.isRunning = !this.isRunning;
      this.data = {
        timeLeft: this.timeLimit,
        isRunning: this.isRunning
      }
      this.sharedService.passData(this.data);

      // this.sharedService.timerPause$.subscribe(
      //   result => {
      //     console.log(result);
      //     this.timeRemaining = result;
      //     this.isRunning = false;
      //     this.data = {
      //       timeLeft: this.timeRemaining,
      //       isRunning: this.isRunning
      //     }
      //     this.sharedService.passData(this.data);
      //   }
      // );
    }
    this.input.nativeElement.value = '';
    

  }

}
