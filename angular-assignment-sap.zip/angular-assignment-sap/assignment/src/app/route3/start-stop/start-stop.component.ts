import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { SharedService } from './../shared.service';

@Component({
  selector: 'app-start-stop',
  templateUrl: './start-stop.component.html',
  styleUrls: ['./start-stop.component.scss']
})
export class StartStopComponent implements OnInit {

  @ViewChild('input') input: ElementRef;
  timeLimit: number;
  timeRemaining: number;
  isStop: boolean;
  isRunning: boolean = false;
  interval;
  data: {};
  time;
  startingMessage: string;
  pauseMessage: string;
  dateTime: string;

  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sharedService.timerPause$.subscribe(
      data => {
        console.log(data);
        this.timeLimit = data.timeLeft;
        this.isRunning = data.isRunning;
      }
    )
  }

  timerStart() {
    if (this.isRunning == false) {
      if (this.timeLimit) {
        console.log(this.timeLimit);
      } else {
        this.timeLimit = this.input.nativeElement.value;
      }
      this.isRunning = !this.isRunning;
      this.data = {
        timeLeft: this.timeLimit,
        isRunning: this.isRunning
      }
      this.sharedService.passData(this.data);


      /* Code for logger starts */

      this.dateTime = this.getDataTime();
      this.startingMessage = 'Started at ' + this.dateTime;

      this.sharedService.getMessage(this.startingMessage);


    } else {
      this.timeLimit = this.input.nativeElement.value;
      this.isRunning = !this.isRunning;
      this.data = {
        timeLeft: this.timeLimit,
        isRunning: this.isRunning
      }
      this.sharedService.passData(this.data);

      this.dateTime = this.getDataTime();
      this.startingMessage = 'Paused at ' + this.dateTime;
      this.sharedService.getMessage(this.startingMessage);

    }
    this.input.nativeElement.value = '';
    

  }

  getDataTime() {
    var today = new Date();
      var h = today.getHours();
      var m = today.getMinutes();
      var s = today.getSeconds();
      var ampm = h >= 12 ? 'pm' : 'am';
      h = h % 12;
      h = h ? h : 12;

      var dd = String(today.getDate()).padStart(2, '0');
      var mm = String(today.getMonth() + 1).padStart(2, '0');
      var yyyy = today.getFullYear();
      var thisDay = dd + '-' + mm + '-' + yyyy;
      // add a zero in front of numbers<10
      m = this.checkTime(m);
      s = this.checkTime(s);

      this.time = h + ":" + m + ":" + s + ' ' + ampm;
      this.dateTime = thisDay + ' ' + this.time;
      return this.dateTime;
  }

  checkTime(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

}
