import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route3Component } from './route3.component';
import { Route3RoutingModule } from './route3-routing.module';
import { TimerComponent } from './timer/timer.component';
import { StartStopComponent } from './start-stop/start-stop.component';
import { LoggerComponent } from './logger/logger.component';
import { ClickComponent } from './click/click.component';



@NgModule({
  declarations: [Route3Component, TimerComponent, StartStopComponent, LoggerComponent, ClickComponent],
  imports: [
    CommonModule,
    Route3RoutingModule
  ]
})
export class Route3Module { }
