import { Component, OnInit } from '@angular/core';
import { SharedService } from './../shared.service';

@Component({
  selector: 'app-logger',
  templateUrl: './logger.component.html',
  styleUrls: ['./logger.component.scss']
})
export class LoggerComponent implements OnInit {

  msg: Array<String> = [];

  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sharedService.message$
      .subscribe(data => {
        this.msg.push(data);
      })
  }

}
