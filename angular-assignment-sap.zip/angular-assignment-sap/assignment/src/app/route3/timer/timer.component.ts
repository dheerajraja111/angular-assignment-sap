import { Component, OnInit } from '@angular/core';
import { SharedService } from './../shared.service';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.scss']
})
export class TimerComponent implements OnInit {

  timeLeft: number;
  timeRemaining;
  interval;
  data: {};
  isRunning: boolean;

  constructor(private sharedService: SharedService) { }

  ngOnInit(): void {
    this.sharedService.timerInput$
      .subscribe(data => {

        console.log(data);
        this.timeLeft = data.timeLeft;

        if (data.isRunning == true) {
          this.interval = setInterval(() => {
            if(this.timeLeft > 0) {
              this.timeLeft--;
              this.timeRemaining = this.timeLeft;
            } else {
              // this.timeLeft = 1000;
            }
          }, 1000);  
        } else {
          console.log(this.timeRemaining);
          this.timeLeft = this.timeRemaining;
          this.isRunning = false;
          
          console.log(this.timeLeft);
          clearInterval(this.interval);
          this.data = {
            timeLeft: this.timeLeft,
            isRunning: this.isRunning
          }

          this.sharedService.pauseTimer(this.data);
        }

      }
      );
  }

}
