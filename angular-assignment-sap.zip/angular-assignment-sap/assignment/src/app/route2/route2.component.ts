import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-route2',
  templateUrl: './route2.component.html',
  styleUrls: ['./route2.component.scss']
})
export class Route2Component implements OnInit {

  @ViewChild('select') select: HTMLSelectElement;

  constructor() { }

  ngOnInit(): void {
  }

  onChange() {
    
  }

}
