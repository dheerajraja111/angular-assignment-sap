import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route2Component } from './route2.component';
import { Route2RoutingModule } from './route2-routing.module';
import { MatButtonToggleModule } from '@angular/material/button-toggle';


@NgModule({
  declarations: [Route2Component],
  imports: [
  CommonModule,
    Route2RoutingModule,
    MatButtonToggleModule
  ]
})
export class Route2Module { }
