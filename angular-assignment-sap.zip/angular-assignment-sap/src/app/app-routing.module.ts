import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  
  { path: '', redirectTo: '/route1', pathMatch: 'full' },

  { 
    path: 'route2', 
    // loadChildren: './route2/route2.module#Route2Module' 
    loadChildren: () => import('./route2/route2.module').then(m => m.Route2Module)
  },
  { 
    path: 'route3', 
    loadChildren: () => import('./route3/route3.module').then(m => m.Route3Module)
  },
  { 
    path: 'route4', 
    loadChildren: () => import('./route4/route4.module').then(m => m.Route4Module)
  },
  { 
    path: 'route5', 
    loadChildren: () => import('./route5/route5.module').then(m => m.Route5Module)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
